import { C as Card_vue_vue_type_style_index_0_lang } from '../styles.mjs';

const CardStyles_ce0c899a = [Card_vue_vue_type_style_index_0_lang];

export { CardStyles_ce0c899a as default };
//# sourceMappingURL=Card-styles.ce0c899a.mjs.map
