import { a as app_vue_vue_type_style_index_0_lang } from '../styles.mjs';

const appStyles_f71c60ae = [app_vue_vue_type_style_index_0_lang];

export { appStyles_f71c60ae as default };
//# sourceMappingURL=app-styles.f71c60ae.mjs.map
