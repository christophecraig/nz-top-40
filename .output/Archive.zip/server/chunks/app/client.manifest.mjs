const client_manifest = {
  "node_modules/nuxt/dist/app/entry.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "entry.c81214f1.js",
    "src": "node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "virtual:nuxt:/Users/christophecraig/Dev/nz-top-40/.nuxt/error-component.mjs",
      "node_modules/nuxt/dist/app/entry.mjs-css"
    ],
    "css": []
  },
  "entry.3d3a871d.css": {
    "file": "entry.3d3a871d.css",
    "resourceType": "style"
  },
  "virtual:nuxt:/Users/christophecraig/Dev/nz-top-40/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "error-component.9ed7373e.js",
    "src": "virtual:nuxt:/Users/christophecraig/Dev/nz-top-40/.nuxt/error-component.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ]
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "file": "error-404.6d3323bb.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "__plugin-vue_export-helper.a1a6add7.js"
    ],
    "css": []
  },
  "error-404.18ced855.css": {
    "file": "error-404.18ced855.css",
    "resourceType": "style"
  },
  "__plugin-vue_export-helper.a1a6add7.js": {
    "resourceType": "script",
    "module": true,
    "file": "_plugin-vue_export-helper.a1a6add7.js"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "file": "error-500.51ff12e1.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "__plugin-vue_export-helper.a1a6add7.js"
    ],
    "css": []
  },
  "error-500.e60962de.css": {
    "file": "error-500.e60962de.css",
    "resourceType": "style"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.3d3a871d.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.18ced855.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.e60962de.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/nuxt/dist/app/entry.mjs-css": {
    "file": "",
    "css": [
      "entry.3d3a871d.css"
    ]
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
